^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yumi_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.4 (2017-01-12)
------------------

0.0.2 (2017-01-10)
------------------
* moveit support for yumi with trajectory downloading using industrial abb drivers
* added chomp interfaces
* Contributors: Todor Stoyanov
